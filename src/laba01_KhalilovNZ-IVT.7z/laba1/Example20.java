package laba1;

public class Example20 {
    public static void main(String[] args) {
        double a = 2.0;
        double b = 3.0;
        //pow(double a, double b): возвращает число a, возведенное в степень b
        double result = Math.pow(a, b);
        System.out.println(a + " в степени " + b + " равно: " + result);
    }
}
